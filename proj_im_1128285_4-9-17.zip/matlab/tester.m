clear all; close all;
global env;
env.MFCCcompression = false;
env.reloadData = false;
env.os = getenv('OS');
env.computeDTW = false;
%%{
global commands;
addpath('lib');
%% READING AUDIO FILES (LABELED)
if (strcmp(env.os,'Windows_NT'));
    env.dirName = '..\dataset\';
    env.slash = '\';
else
    env.dirName = '../dataset/';
    env.slash = '/';
end
if (env.reloadData)
    d = dir(env.dirName);
    isub = [d(:).isdir]; %# returns logical vector
    nameFolds = {d(isub).name}';
    nameFolds(ismember(nameFolds,{'.','..'})) = [];
    commands = cell(size(nameFolds,1),1);
    for i=1:size(nameFolds,1)
        disp(strcat('comando: ',nameFolds{i}));
        fileList = getAllFiles(strcat(env.dirName,nameFolds{i}));
        audioFiles = cell(size(fileList,1),3);
        for j=1:size(fileList,1)
            [audioFiles{j,1}, audioFiles{j,2}] = audioread(fileList{j});
            audioFiles{j,3} = fileList{j};
        end
        commands{i}.description = nameFolds{i};
        commands{i}.audio = audioFiles;
    end
    clearvars audioFiles d dirName fileList i isub j nameFolds;
    save(strcat('mat',env.slash,'audio_loaded.mat'),'commands');
else
    load(strcat('mat',env.slash,'audio_loaded.mat'));
end

env.mfccComprThreshold = 1;
env.lpcN = 12;
env.mfccN = 12;
%% ENHANCING AUDIO
% performs speech enhancement using mmse estimate
addpath(strcat('voicebox',env.slash));
% for i=1:size(commands,1)
%     for j=1:size(commands{i}.audio,1)
%         row = commands{i}.audio(j,:);
%         commands{i}.audio{j,1} = ...
%             ssubmmsev(row{1}, row{2});
%     end
% end
%% FEATURES EXTRACTION FROM AUDIO
for i=1:size(commands,1)
    for j=1:size(commands{i}.audio,1)
        row = commands{i}.audio(j,:);
        [activeLevel, activityFactor] = activlev(row{1}, row{2});
        %mfcc = melcepst(row{1}, row{2});
        mfcc = melcepst(row{1}, row{2}, 'N');
        % mfcc compression
        if env.MFCCcompression
            l = size(mfcc,1);
            k = 1;
            while (k<l)
                if (norm(mfcc(k,:)-mfcc(k+1,:))<env.mfccComprThreshold)
                    mfcc(k,:) = (mfcc(k,:)+mfcc(k+1,:))./2;
                    mfcc(k+1,:) = [];
                end
                k = k+1;
                l = size(mfcc,1);
            end
        end
        % end of mfcc compression
        %commands{i}.features(j,1).activeLevel = activeLevel;
        %commands{i}.features(j,1).activityFactor = activityFactor;
        commands{i}.features(j,1).mfcc = mfcc;
        %commands{i}.features(j,1).desc = get_descriptor(mfcc,env.lpcN)';
    end
end
clearvars activeLevel activityFactor i j row mfcc k l;

%% SPLITTING DATA BETWEEN TRAINING AND TESTING
rng('default');
Ntot = size(commands{1,1}.audio,1);
Ntr = floor(.8*Ntot);
ind = randperm(Ntot);
Ncl = length(commands);
data_tr = cell(Ntr,Ncl);
data_te = cell(Ntot-Ntr,Ncl);
for i=1:Ntr
    for j=1:Ncl
        data_tr{i,j} = commands{j}.features(ind(i)).mfcc;
    end
end
for i=Ntr+1:Ntot
    for j=1:Ncl
        data_te{i-Ntr,j} = commands{j}.features(ind(i)).mfcc;
    end
end
clearvars i j;
%%}
%% CALCULATING DTW AND OPTIMAL PATHS
%%{
%%}
% testing
%{
class1 = 1;
class2 = 2;
row1 = 2;
row2 = 16;
disp(strcat('from class-',int2str(class1),' to class-',int2str(class2)));
disp(strcat('L1=',int2str(size(data_tr{row1,class1},1)),...
    ',L2=',int2str(size(data_tr{row2,class2},1))));
[tmp1, tmp2] = MFCCmatch(data_tr{row1,class1},data_tr{row2,class2});
disp(strcat('from :',int2str(tmp2(1,1)),',',int2str(tmp2(1,2))));
disp(strcat(' to  :',int2str(tmp2(end,1)),',',int2str(tmp2(end,2))));
disp(strcat('DTW :',num2str(tmp1)));
class1 = 1;
class2 = 1;
row1 = 3;
row2 = 2;
disp(strcat('from class-',int2str(class1),' to class-',int2str(class2)));
disp(strcat('L1=',int2str(size(data_tr{row1,class1},1)),...
    ',L2=',int2str(size(data_tr{row2,class2},1))));
[tmp3, tmp4] = MFCCmatch(data_tr{row1,class1},data_tr{row2,class2});
disp(strcat('from :',int2str(tmp4(1,1)),',',int2str(tmp4(1,2))));
disp(strcat(' to  :',int2str(tmp4(end,1)),',',int2str(tmp4(end,2))));
disp(strcat('DTW :',num2str(tmp3)));
clearvars class1 class2 row1 row2;
%}
% end testing
%%{
if (env.computeDTW)
    dtw = cell(Ncl);
    path = cell(Ncl);
    tic;
    for j=1:Ncl
        for l=j:Ncl
            dtw{j,l} = zeros(Ntr);
            path{j,l} = cell(Ntr);
            for i=1:Ntr
                for k=i:Ntr
                    % dtw tra
                    % i-esimo elemento della j-esima classe e
                    % k-esimo elemento della l-esima classe
                    [dtw{j,l}(i,k), path{j,l}{i,k}] = ...
                        MFCCmatch(data_tr{i,j},data_tr{k,l});
                end
                for k=i+1:Ntr
                    dtw{j,l}(k,i) = dtw{j,l}(i,k);
                    path{j,l}{k,i} = fliplr(path{j,l}{i,k});
                end
            end
            disp(strcat('class-',int2str(j),' : class-',int2str(l),' done'));
            toc;
        end
        for l=j+1:Ncl
            dtw{l,j} = dtw{j,l};
            path{l,j} = fliplr(path{j,l});
        end
        disp(strcat('class-',int2str(j),' done'));
        toc;
    end
    clearvars i j k l;
    save(strcat('mat',env.slash,'dtw.mat'),'dtw', 'path');
else
    load(strcat('mat',env.slash,'dtw.mat'));
end
%% TRAINING ALGORITHM
%% RANSAC
% means = zeros(Ncl);
% variances = zeros(Ncl);
mins = zeros(Ncl);
maxs = zeros(Ncl);
medians = cell(Ncl,1);
env.nRansac = uint8(Ntr);
env.AR = 0.8;
env.falseMatch = 0.8;
env.normalize = true;
%rng(3);
%disp(int2str(3));
for i=1:Ncl
    for j=1:Ncl
%         I = randperm(size(dtw{i,j},1));
%         means(i,j) = mean(mean(dtw{i,j}(I(1:env.nRansac),:),2));
%         variances(i,j) = var(var(dtw{i,j}(I(1:env.nRansac),:),0,2));
        mins(i,j) = min(dtw{i,j}(:));
        maxs(i,j) = max(dtw{i,j}(:));
    end
end
for i=1:Ncl
    I = inf(size(dtw{i,i},1),4);
    [I(:,3),I(:,1)] = sortrows(mean(dtw{i,i},2)); % I(:,3) must be small
    others = 1:Ncl;
    others(others==i)=[];
    for j=1:size(I,1)
        for k=1:Ncl-1 % I(:,2) must be large
            I(j,2) = min([I(j,2), min(dtw{i,others(k)}(I(j,1),:))]);
        end
    end
    if (env.normalize)
        I(:,2) = I(:,2) / max(I(:,2));
        I(:,3) = I(:,3) / max(I(:,3));
    end
    I(:,4) = I(:,2)*(1+env.falseMatch)-I(:,3);
    I = sortrows(I,4);
    I = flipud(I);
    %[~, env.nRansac] = max(diff(I(:,4)));
    %env.nRansac = find(I(:,4)>mean(I(:,4)), 1, 'last' );
    I = I(:,1);
    med = cell(1);
    l = 0;
    k=1;
    while (length(I)>ceil(env.nRansac/4))
        tmp = dtw{i,i}(I(1),:);
        tmp(I(1)) = [];
        while (1)
            [~,ind] = min(tmp);
            if (~isempty(I(I==ind)))
                break;
            end
            tmp(ind) = [];
        end
        med{k} = MFCCmean(data_tr{I(1),i},data_tr{ind,i},path{i,i}{I(1),ind});
        k = k+1;
        l = l + size(data_tr{I(1),i},1) + size(data_tr{ind,i},1);
        I(1) = [];
        I(I==ind) = [];
    end
    l = l / env.nRansac / 2;
    medians{i} = med{1};
    for k=2:length(med)
        [~,p] = MFCCmatch(medians{i},med{k});
        medians{i} = MFCCmean(medians{i},med{k},p,env.AR);
%         medians{i} = MFCCreduce(medians{i},max([size(medians{i},1),size(med{k},1)]));
    end
    medians{i} = MFCCreduce(medians{i},l);
end
clearvars i j k l p tmp med I ind others;
CI = zeros(Ncl,1); % confidence intervals
for i=1:Ncl
    tmp = sort(mins(i,:));
    CI(i) = tmp(2);
end
env.CI = CI;
env.mins = mins;
env.maxs = maxs;
clearvars tmp i j CI mins maxs;
%% TESTING
Nte = Ntot - Ntr;
classified = zeros(size(data_te));
wrong = zeros(1,Ncl);
for i=1:Nte
    for j=1:Ncl
        tested = data_te{i,j};
        result = zeros(Ncl,1);
        for k=1:Ncl
            [result(k,1), ~] = MFCCmatch(tested,medians{k});
        end
        [v, res] = sort(result,1);
        if (v(1)<env.CI(res(1))) % I'm quite sure
            classified(i,j) = res(1);
        elseif (v(1)<env.maxs(res(1),res(1))) % I'm still confident
            classified(i,j) = res(1);
        else % better not to classify anyting
            classified(i,j) = inf;
        end
        if (classified(i,j)~=j)
            %disp(strcat('error.{i,j}={',int2str(i),',',int2str(j),'}'));
            wrong(j) = wrong(j) + 1;
        end
    end
end
env.accuracy = (1-sum(wrong)/length(data_te(:)))*100;
env.wrong = wrong;
disp(strcat('accuracy=',num2str(env.accuracy),'%'));
env.classified = classified;
env.medians = medians;
clearvars i j k res tested result v classified medians wrong;
save(strcat('out',env.slash,'acc_',num2str(env.accuracy),'_',...
    datestr(datetime('now'),'yy-mm-dd_HH-MM-SS'),'.mat'),'env');

